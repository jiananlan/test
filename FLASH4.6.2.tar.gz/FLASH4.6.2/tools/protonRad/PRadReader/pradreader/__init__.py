"""Package for reading various High Energy Density Physics proton radiography formats."""

__version__ = '0.0.1'

from . import reader
