
README FOR 'FLASH4.5/tools/protonRad' DIRECTORY
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This folder contains snapshots of GitHub packages authored by the Flash Center which are useful
in proton radiography analysis.

1. PRaLine: A python code for proton radiography reconstruction based on Graziani et al., 2017.
2. PRadReader: A required dependency of PRaLine. Install first.

This README outlines their installation and usage.

##############################################
  INSTALLATION/USAGE OF UP-TO-DATE VERSIONS
##############################################

If you have internet access, it is highly recommended to download and install the latest
versions of these python packages, rather than installing from these local snapshots. Follow
instructions at:

PRaLine: https://github.com/flash-center/PRaLine
PRadReader: https://github.com/flash-center/PRadReader

Up-to-date installation guides, usage instructions, and examples will also be found at these
websites.

##############################################
  INSTALLATION/USAGE OF LOCAL SNAPSHOTS
##############################################

Note: Local snapshots are in an alpha release state!

If you prefer to install from the local snapshots included with the FLASH code, what follows is
a Quick Start guide. Further installation and usage details can be found in
'./PRadReader/README.md' and './PRaLine/README.md'.

DEPENDENCIES
Prior to installation, ensure the folowing python package dependencies are satisfied:
 * future/builtins
 * numpy
 * scipy
 * matplotlib
 * pandas
 * PRadReader

All dependencies except the last can be satisfied with the python package manager via
"pip install future numpy scipy matplotlib pandas".

Once the first five dependencies are satisfied, navigate into PRadReader directory, and install
the final dependency via "python setup.py install".

INSTALLATION
After all dependencies are satisfied, navigate into PRaLine directory, and install the PRaLine
package via "python setup.py install".

RUNNING THE EXAMPLE
The local snapshot of PRaLine includes an example which analyzes proton radiographs to generate
the magnetic field plots presented Graziani et al., 2017. This example input file is located in
'./PRaLine/examples' and can be analyzed after installation.

To try this example, first navigate into './PRaLine/examples', Then run the example via
'lin-analyze test_input.p' (generate flux maps) and 'lin-reconstruct test_input.p' (reconstruct
magnetic field, 4000 iterations). Output files will be generated in the same folder upon
completion.

More information about running and interpreting the example can be found in './PRaLine/README.md'.


- README by Scott Feister, 2017-11-17 (Updated 2017-11-21)
