Syntax and Trajectory options for the trajectory sorter.

usage:

trajectoryConvert [options] fileBasename startNumber endNumber

file basename: flash filename sans file number. i.e. sod_hdf5_part_  
     	       Split not directly supported at this time
	       particle file assumed

startNumber: the file output number to start at.  usually 0000.
endNumber:   the final particle file number to use.
