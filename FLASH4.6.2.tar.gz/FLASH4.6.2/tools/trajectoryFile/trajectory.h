#ifndef __TRAJECTORY_H
#define __TRAJECTORY_H

#define NONEXISTENT -1
#define HUGE 99999999
#define PADDING 20
 



#endif
