#ifndef CONSTANTS_H
#define CONSTANTS_H

#define MAX_STRING_LENGTH 80
#define STRINGSIZE 256
#define UNK_NAME_LEN 4

#define READ_FAILURE -1
#define WRITE_FAILURE -2

#endif
