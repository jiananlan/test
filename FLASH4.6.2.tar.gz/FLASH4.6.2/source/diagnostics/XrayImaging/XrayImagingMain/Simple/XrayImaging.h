#if 0
    This file contains the indices of the various attributes used within the X-ray
    Imaging unit.
#endif

#if 0
    X-ray stuff

    Currently the XRAY_ATTRCOUNT has to match the setting of the RAY_ATTR_COUNT,
    PROTON_ATTRCOUNT and EMPROTON_ATTRCOUNT. This has to be done to circumvent the
    shortcomings of the grid particles unit, which uses sending and destination buffers
    of fixed size determined during inititialization of the grid particle unit (gr_ptInit). If
    XRAY_ATTRCOUNT, PROTON_ATTRCOUNT, EMPROTON_ATTRCOUNT and RAY_ATTR_COUNT do not match,
    the gr_ptInit issues a message and stops the calculations.

    XRAY_ATTRCOUNT : total number of X-ray attributes

    XRAY_POSX : the x coordinate of the X-ray
    XRAY_POSY : the y coordinate of the X-ray
    XRAY_POSZ : the z coordinate of the X-ray
    XRAY_POSR : the r coordinate of the X-ray (only relevant for 2D cylindrical geometries)
    XRAY_DIRX : the x direction component of the X-ray
    XRAY_DIRY : the y direction component of the X-ray
    XRAY_DIRZ : the z direction component of the X-ray
    XRAY_PXLI : the integer pixel i coordinate on the detector screen of the X-ray
    XRAY_PXLJ : the integer pixel j coordinate on the detector screen of the X-ray
    XRAY_BLCK : block number identifier of X-ray
    XRAY_PROC : processor number of X-ray
    XRAY_TAGS : globally unique X-ray tag
    XRAY_ATTN : attenuation of X-ray

#endif

#define XRAY_ATTRCOUNT  16

#define XRAY_POSX 1
#define XRAY_POSY 2
#define XRAY_POSZ 3
#define XRAY_POSR 4
#define XRAY_DIRX 5
#define XRAY_DIRY 6
#define XRAY_DIRZ 7
#define XRAY_PXLI 8
#define XRAY_PXLJ 9
#define XRAY_BLCK 10
#define XRAY_PROC 11
#define XRAY_TAGS 12
#define XRAY_ATTN 13

#if 0
    Screen X-ray stuff

    SCREEN_ATTRCOUNT : total number of screen X-ray attributes

    SCREEN_POSX : the screen x coordinate of the screen X-ray
    SCREEN_POSY : the screen y coordinate of the screen X-ray
    SCREEN_INTY : the intensity of the screen X-ray
    SCREEN_DETC : detector number of screen X-ray

#endif

#define SCREEN_ATTRCOUNT  4

#define SCREEN_POSX 1
#define SCREEN_POSY 2
#define SCREEN_INTY 3
#define SCREEN_DETC 4

#if 0
    Geometry stuff

    GRID_1DCARTESIAN   : Handle for domain geometry
    GRID_2DCARTESIAN   : Handle for domain geometry
    GRID_3DCARTESIAN   : Handle for domain geometry
    GRID_1DCYLINDRICAL : Handle for domain geometry
    GRID_2DCYLINDRICAL : Handle for domain geometry
    GRID_3DCYLINDRICAL : Handle for domain geometry
    GRID_1DSPHERICAL   : Handle for domain geometry
    GRID_2DSPHERICAL   : Handle for domain geometry
    GRID_3DSPHERICAL   : Handle for domain geometry
    GRID_1DPOLAR       : Handle for domain geometry
    GRID_2DPOLAR       : Handle for domain geometry
    GRID_3DPOLAR       : Handle for domain geometry
#endif

#define GRID_1DCARTESIAN    1
#define GRID_2DCARTESIAN    2
#define GRID_3DCARTESIAN    3
#define GRID_1DCYLINDRICAL  4
#define GRID_2DCYLINDRICAL  5
#define GRID_3DCYLINDRICAL  6
#define GRID_1DSPHERICAL    7
#define GRID_2DSPHERICAL    8
#define GRID_3DSPHERICAL    9
#define GRID_1DPOLAR        10
#define GRID_2DPOLAR        11
#define GRID_3DPOLAR        12
