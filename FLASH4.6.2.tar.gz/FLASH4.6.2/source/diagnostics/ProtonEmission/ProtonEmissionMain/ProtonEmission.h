#if 0
    This file contains the indices of the various attributes used within the Proton
    Emission unit.
#endif

#if 0
    Emission proton source reaction stuff

    EMPROTON_REACTION_COUNT    : total number of proton source reactions
    EMPROTON_REACTION_DDPT     : the proton source fusion reaction D + D -> p + T 
    EMPROTON_REACTION_HE3DPHE4 : the proton source fusion reaction He3 + D -> p + He4 

#endif

#define EMPROTON_REACTION_COUNT    2
#define EMPROTON_REACTION_DDPT     1
#define EMPROTON_REACTION_HE3DPHE4 2

#if 0
    Emission proton source fuel stuff

    EMPROTON_FUEL_COUNT : total number of proton source fuels
    EMPROTON_FUEL_D     : the proton source fuel Deuterium
    EMPROTON_FUEL_HE3   : the proton source fuel Helium 3

#endif

#define EMPROTON_FUEL_COUNT  2
#define EMPROTON_FUEL_D      1
#define EMPROTON_FUEL_HE3    2

#if 0
    Emission proton stuff

    Currently the EMPROTON_ATTRCOUNT has to match the setting of the RAY_ATTR_COUNT
    and PROTON_ATTRCOUNT. This has to be done to circumvent the shortcomings of the
    grid particles unit, which uses sending and destination buffers of fixed size
    determined during inititialization of the grid particle unit (gr_ptInit). If
    EMPROTON_ATTRCOUNT, PROTON_ATTRCOUNT and RAY_ATTR_COUNT do not match, the gr_ptInit
    issues a message and stops the calculations.

    EMPROTON_ATTRCOUNT : total number of emission proton attributes

    EMPROTON_POSX : the x coordinate of the emission proton
    EMPROTON_POSY : the y coordinate of the emission proton
    EMPROTON_POSZ : the z coordinate of the emission proton
    EMPROTON_VELX : the x velocity component of the emission proton
    EMPROTON_VELY : the y velocity component of the emission proton
    EMPROTON_VELZ : the z velocity component of the emission proton
    EMPROTON_BLCK : block number identifier of emission proton
    EMPROTON_PROC : processor number of emission proton
    EMPROTON_TAGS : globally unique emission proton tag

#endif

#define EMPROTON_ATTRCOUNT  16

#define EMPROTON_POSX 1
#define EMPROTON_POSY 2
#define EMPROTON_POSZ 3
#define EMPROTON_VELX 4
#define EMPROTON_VELY 5
#define EMPROTON_VELZ 6
#define EMPROTON_BLCK 7
#define EMPROTON_PROC 8
#define EMPROTON_TAGS 9

#if 0
    Screen emission proton stuff

    EMSCREEN_ATTRCOUNT : total number of screen emission proton attributes

    EMSCREEN_POSX : the screen x coordinate of the screen emission proton
    EMSCREEN_POSY : the screen y coordinate of the screen emission proton
    EMSCREEN_DETC : detector number of screen emission proton

#endif

#define EMSCREEN_ATTRCOUNT  3

#define EMSCREEN_POSX 1
#define EMSCREEN_POSY 2
#define EMSCREEN_DETC 3

#if 0
    Emission cone stuff

    The EMCONE_ARRAYSIZE sets the array size for retrieving the x,y,z spherical cone
    triples.
#endif

#define EMCONE_ARRAYSIZE  1000

#if 0
    Geometry stuff

    GRID_1DCARTESIAN   : Handle for domain geometry
    GRID_2DCARTESIAN   : Handle for domain geometry
    GRID_3DCARTESIAN   : Handle for domain geometry
    GRID_1DCYLINDRICAL : Handle for domain geometry
    GRID_2DCYLINDRICAL : Handle for domain geometry
    GRID_3DCYLINDRICAL : Handle for domain geometry
    GRID_1DSPHERICAL   : Handle for domain geometry
    GRID_2DSPHERICAL   : Handle for domain geometry
    GRID_3DSPHERICAL   : Handle for domain geometry
    GRID_1DPOLAR       : Handle for domain geometry
    GRID_2DPOLAR       : Handle for domain geometry
    GRID_3DPOLAR       : Handle for domain geometry
#endif

#define GRID_1DCARTESIAN    1
#define GRID_2DCARTESIAN    2
#define GRID_3DCARTESIAN    3
#define GRID_1DCYLINDRICAL  4
#define GRID_2DCYLINDRICAL  5
#define GRID_3DCYLINDRICAL  6
#define GRID_1DSPHERICAL    7
#define GRID_2DSPHERICAL    8
#define GRID_3DSPHERICAL    9
#define GRID_1DPOLAR        10
#define GRID_2DPOLAR        11
#define GRID_3DPOLAR        12
