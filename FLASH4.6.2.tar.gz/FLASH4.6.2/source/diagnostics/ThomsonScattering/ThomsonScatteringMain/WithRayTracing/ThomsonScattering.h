#if 0
    This file contains the indices of the various attributes used with Ray tracing
    in Thomson Scattering routines
#endif

#if 0
    Thomson Ray stuff

    Currently the TRAY_ATTRCOUNT has to match the setting of the RAY_ATTR_COUNT (from
    energy deposition), PROTON_ATTRCOUNT (from proton imaging) and EMPROTON_ATTRCOUNT
    (from proton emission). This has to be done to circumvent the shortcomings of the
    grid particles unit, which uses sending and destination buffers of fixed size
    determined during inititialization of the grid particle unit (gr_ptInit). If
    TRAY_ATTRCOUNT, RAY_ATTR_COUNT, EMPROTON_ATTRCOUNT and PROTON_ATTRCOUNT do not match,
    the gr_ptInit issues a message and stops the calculations.

    TRAY_ATTRCOUNT : total number of Thomson ray attributes

    TRAY_POSX : the x coordinate of the Thomson ray at a given instant
    TRAY_POSY : the y coordinate of the Thomson ray at a given instant
    TRAY_POSZ : the z coordinate of the Thomson ray at a given instant
    TRAY_VELX : the x velocity component of the Thomson ray at a given instant
    TRAY_VELY : the y velocity component of the Thomson ray at a given instant
    TRAY_VELZ : the z velocity component of the Thomson ray at a given instant
    TRAY_POWR : the power of the Thomson ray in erg/s
    TRAY_DENC : the critical density corresponding to the Thomson ray laser frequency
    TRAY_BLCK : block number identifier of Thomsonray
    TRAY_BEAM : beam number identifier of Thomsonray
    TRAY_PROC : processor number of Thomson ray
    TRAY_TAGS : globally unique Thomson ray tag
    TRAY_TYPE : designates the type of Thomson ray, laser or detector

    TRAY_LASERTYPE    : indicator for laser type Thomson rays
    TRAY_DETECTORTYPE : indicator for detector type Thomson rays
#endif

#define TRAY_ATTRCOUNT  16

#define TRAY_POSX 1
#define TRAY_POSY 2
#define TRAY_POSZ 3
#define TRAY_VELX 4
#define TRAY_VELY 5
#define TRAY_VELZ 6
#define TRAY_POWR 7
#define TRAY_DENC 8
#define TRAY_BLCK 9
#define TRAY_BEAM 10
#define TRAY_PROC 11
#define TRAY_TAGS 12
#define TRAY_TYPE 13

#define TRAY_LASERTYPE    1
#define TRAY_DETECTORTYPE 0

#if 0
    Interaction region stuff

    IR_RAYI_ATTRCOUNT : total number of incident (laser) ray interaction region attributes
    IR_RAYS_ATTRCOUNT : total number of scattered (detector) ray interaction region attributes
    IR_CELL_ATTRCOUNT : total number of cell interaction region attributes

    IR_DIRX : the x direction component of the IR ray in the IR cell
    IR_DIRY : the y direction component of the IR ray in the IR cell
    IR_DIRZ : the z direction component of the IR ray in the IR cell
    IR_POWR : the power of the IR ray in erg/s entering the IR cell
    IR_DIST : the distance the IR ray travelled in the IR cell (for laser ray only)

    IR_NELE : the number electron density of the IR cell
    IR_TELE : the electron temperature of the IR cell
    IR_TION : the ion temperature of the IR cell
    IR_CENX : the x-component of the IR cell center location
    IR_CENY : the y-component of the IR cell center location
    IR_CENZ : the z-component of the IR cell center location
    IR_VELX : the x-component of the bulk fluid velocity in the IR cell
    IR_VELY : the y-component of the bulk fluid velocity in the IR cell
    IR_VELZ : the z-component of the bulk fluid velocity in the IR cell
#endif

#define IR_RAYI_ATTRCOUNT  5
#define IR_RAYS_ATTRCOUNT  4
#define IR_CELL_ATTRCOUNT  9

#define IR_DIRX 1
#define IR_DIRY 2
#define IR_DIRZ 3
#define IR_POWR 4
#define IR_DIST 5

#define IR_NELE 1
#define IR_TELE 2
#define IR_TION 3
#define IR_CENX 4
#define IR_CENY 5
#define IR_CENZ 6
#define IR_VELX 7
#define IR_VELY 8
#define IR_VELZ 9

#if 0
    Beam stuff

    BEAM_STRING_LENGTH  : the maximum character string length to accomodate beam info
    BEAM_GRID_ARRAYSIZE : the size of each grid array when retrieving all grid points
#endif

#define BEAM_STRING_LENGTH  20
#define BEAM_GRID_ARRAYSIZE 10

#if 0
    Geometry stuff

    GRID_1DCARTESIAN   : Handle for domain geometry
    GRID_2DCARTESIAN   : Handle for domain geometry
    GRID_3DCARTESIAN   : Handle for domain geometry
    GRID_1DCYLINDRICAL : Handle for domain geometry
    GRID_2DCYLINDRICAL : Handle for domain geometry
    GRID_3DCYLINDRICAL : Handle for domain geometry
    GRID_1DSPHERICAL   : Handle for domain geometry
    GRID_2DSPHERICAL   : Handle for domain geometry
    GRID_3DSPHERICAL   : Handle for domain geometry
    GRID_1DPOLAR       : Handle for domain geometry
    GRID_2DPOLAR       : Handle for domain geometry
    GRID_3DPOLAR       : Handle for domain geometry
#endif

#define GRID_1DCARTESIAN    1
#define GRID_2DCARTESIAN    2
#define GRID_3DCARTESIAN    3
#define GRID_1DCYLINDRICAL  4
#define GRID_2DCYLINDRICAL  5
#define GRID_3DCYLINDRICAL  6
#define GRID_1DSPHERICAL    7
#define GRID_2DSPHERICAL    8
#define GRID_3DSPHERICAL    9
#define GRID_1DPOLAR        10
#define GRID_2DPOLAR        11
#define GRID_3DPOLAR        12
