#if 0
    This file contains the indices of the various attributes used within the Thomson
    Imaging unit.
#endif

#if 0
    Thomson stuff

    THOMSON_ATTRCOUNT : total number of Thomson light ray attributes

    THOMSON_POSX : the x coordinate of the Thomson light ray
    THOMSON_POSY : the y coordinate of the Thomson light ray
    THOMSON_POSZ : the z coordinate of the Thomson light ray
    THOMSON_VELX : the x velocity component of the Thomson light ray
    THOMSON_VELY : the y velocity component of the Thomson light ray
    THOMSON_VELZ : the z velocity component of the Thomson light ray
    THOMSON_BLCK : block number identifier of Thomson light ray
    THOMSON_PROC : processor number of Thomson light ray
    THOMSON_TAGS : globally unique Thomson light ray tag
    THOMSON_BEAM : beam number where Thomson light ray originated from
    THOMSON_DETC : target detector number of Thomson light ray
    THOMSON_DGJV : the diagnostic total path magnetic current value of the Thomson light ray
    THOMSON_DGKX : the diagnostic total path Bx value of the Thomson light ray
    THOMSON_DGKY : the diagnostic total path By value of the Thomson light ray
    THOMSON_DGKZ : the diagnostic total path Bz value of the Thomson light ray

#endif

#if 0
#define THOMSON_ATTRCOUNT  15

#define THOMSON_POSX 1
#define THOMSON_POSY 2
#define THOMSON_POSZ 3
#define THOMSON_VELX 4
#define THOMSON_VELY 5
#define THOMSON_VELZ 6
#define THOMSON_BLCK 7
#define THOMSON_PROC 8
#define THOMSON_TAGS 9
#define THOMSON_BEAM 10
#define THOMSON_DETC 11
#define THOMSON_DGJV 12
#define THOMSON_DGKX 13
#define THOMSON_DGKY 14
#define THOMSON_DGKZ 15
#endif

#if 0
    Detected Thomson light ray stuff

    DETECTOR_ATTRCOUNT : total number of detected Thomson light ray attributes

    DETECTOR_POSX : the screen x coordinate of the detected Thomson light ray
    DETECTOR_POSY : the screen y coordinate of the detected Thomson light ray
    DETECTOR_DETC : detector number of detected Thomson light ray
    DETECTOR_DGJV : the diagnostic total path magnetic current value of the detected Thomson light ray
    DETECTOR_DGKX : the diagnostic total path Bx value of the detected Thomson light ray
    DETECTOR_DGKY : the diagnostic total path By value of the detected Thomson light ray
    DETECTOR_DGKZ : the diagnostic total path Bz value of the detected Thomson light ray
See FormFactor routine for actual doc.
#endif

#define DETECTOR_ATTRCOUNT0 11
#define DETECTOR_ATTRCOUNT  9
#define DETECTOR_ATTRCOUNTFULL (10+24)

#define DETECTOR_DETC  0

#define DETECTOR_TELE  1
#define DETECTOR_TION  2
#define DETECTOR_NELE  3
#define DETECTOR_VPAR  4
#define DETECTOR_VPERP 5
#define DETECTOR_UD    6
#define DETECTOR_SA    7
#define DETECTOR_POWER 8
#define DETECTOR_GAMMA 9

#define DETECTOR_BEAM  10
#define DETECTOR_NATOM 11
#define DETECTOR_CELLX 12
#define DETECTOR_CELLY 13
#define DETECTOR_CELLZ 14
#define DETECTOR_LENSX 15
#define DETECTOR_LENSY 16
#define DETECTOR_LENSZ 17
#define DETECTOR_CELLV 18
#define DETECTOR_ATTEN 19
#define DETECTOR_DPHI  20
#define DETECTOR_FARRO1 21
#define DETECTOR_FARRO2 22
#define DETECTOR_ATTEN2 23
#define DETECTOR_DPHIOUT 24

#if 0
    Thomson light beam stuff

    BEAM_STRINGLENGTH  : the maximum character string length to accomodate beam info

#endif

#define BEAM_STRINGLENGTH  20

#if 0
    Geometry stuff - most of these totally unimplemented for ThomsonScattering!

    GRID_1DCARTESIAN   : Handle for domain geometry
    GRID_2DCARTESIAN   : Handle for domain geometry
    GRID_3DCARTESIAN   : Handle for domain geometry
    GRID_1DCYLINDRICAL : Handle for domain geometry
    GRID_2DCYLINDRICAL : Handle for domain geometry
    GRID_3DCYLINDRICAL : Handle for domain geometry
    GRID_1DSPHERICAL   : Handle for domain geometry
    GRID_2DSPHERICAL   : Handle for domain geometry
    GRID_3DSPHERICAL   : Handle for domain geometry
    GRID_1DPOLAR       : Handle for domain geometry
    GRID_2DPOLAR       : Handle for domain geometry
    GRID_3DPOLAR       : Handle for domain geometry
#endif

#define GRID_1DCARTESIAN    1
#define GRID_2DCARTESIAN    2
#define GRID_3DCARTESIAN    3
#define GRID_1DCYLINDRICAL  4
#define GRID_2DCYLINDRICAL  5
#define GRID_3DCYLINDRICAL  6
#define GRID_1DSPHERICAL    7
#define GRID_2DSPHERICAL    8
#define GRID_3DSPHERICAL    9
#define GRID_1DPOLAR        10
#define GRID_2DPOLAR        11
#define GRID_3DPOLAR        12


#define THSC_LOGLEVEL_WARN_OPER     200
#define THSC_LOGLEVEL_WARN_DATA     300
#define THSC_LOGLEVEL_WARN_USE      400
#define THSC_LOGLEVEL_INFO_FALLBACK 500
#define THSC_LOGLEVEL_INFO_ALL     1000
