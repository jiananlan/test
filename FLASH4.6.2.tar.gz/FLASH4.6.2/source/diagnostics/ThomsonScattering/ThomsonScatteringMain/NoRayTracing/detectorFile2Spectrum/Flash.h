
#define NSPECIES 3
#define MS_MAXELEMS 6
