#ifndef FLASH_H
#define FLASH_H

#define NVAR 1
#define NXB 2
#define NYB 3
#define NZB 4

#endif
