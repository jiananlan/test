#if 0
    This file contains the indices of the various attributes used within the
    Pipeline unit.
#endif

