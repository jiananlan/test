void dbg_heap_check_impl(void);
