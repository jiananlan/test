#include <stdlib.h>
#include "mangle_names.h"
#include "dbg_heap_check_impl.h"

void FTOC(dbg_heap_check)(void);
void FTOC(dbg_disable_heap_check)(void);
void FTOC(dbg_enable_heap_check)(void);
