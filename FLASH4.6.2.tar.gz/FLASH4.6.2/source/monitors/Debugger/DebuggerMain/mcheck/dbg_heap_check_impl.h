#include <stdlib.h>

#ifdef MCHECK
# include <mcheck.h>
#endif

void dbg_heap_check_impl(void);
