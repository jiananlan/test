#include "dbg_heap_check_impl.h"

void dbg_heap_check_impl(void)
{
}
