Need a "ReadFromFile" here, maybe drawing from Virgo Consortium
mass, posx,velx,posy,vely,etc.
