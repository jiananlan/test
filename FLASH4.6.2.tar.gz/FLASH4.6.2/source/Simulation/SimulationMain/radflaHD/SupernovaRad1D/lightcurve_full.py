#!/usr/bin/env python
import h5py
import numpy as np
import matplotlib.pyplot as plt
import time
import math
import sys
import read_opac

#Fix: loop+tabular opac

#Stefan-Boltzmann constant
stefan = 5.67051e-5
#Solar luminosity
Lsun = 1.99e+33

############ THIS SECTION IS THE ONLY ONE TO BE EDITED #######################
#Give path to tabular opacity data directory, opacities taken from MESA
opac_data_path = '/Users/manolis/Desktop/mesa_7624/data/kap_data/'
#Optical depth of photosphere (Default is 2/3).
tau_phot = 2./3.
#Edit check point file identifier (name) all the way before 'chk_'
Check_name = 'mesa_sn_smooth_lc_wdecay_opacmixfull_hdf5_'
#Do a single snapshot or a series of FLASH output? 1 for series, 0 for single
single = 0
#If doing single snapshot give full checkpoint file number (4 digits) as a string
chk_num = '0001'
#If doing series and you want to start from a certain checkpoint > 0 set Nmin
Nmin = 0
#If doing series Provide max number of checkpoint files to be processed
Nmax = 1662
#Increment checkpoint files to read
Nstep = 10
#Choose opacity type
[simple_opac, flash_opac, tabular] = [0,1,2]
opac_source = tabular
#Use additional Ni-decay deposition term only if Heating was done in FLASH.
flash_heat = 1
#Size of FLASH simulation box in order to calculate time-delay to reach edge
Rbox = 4.0e+16
################ DO NOT EDIT BELOW THIS LINE #################################

#Speed of light
c = 2.9999e+10

if single == 0:
    Nmax = 1
else:
    print '#Lightcurve data: Time/Bolometric Luminosity/Photospheric Radius'

for q in range(Nmin,Nmax,Nstep):
    if single == 0:
        string = 'chk_'+chk_num

    else: 
        if q <100:
            string = 'chk_'"0%3.3d" %q

        elif q >= 100 and q < 999:
            string = 'chk_'"0%3.3d" %q

        else:
            string = 'chk_'"%3.3d" %q
        
    infile2 = Check_name+string

    file = h5py.File(infile2,'r') 

#Open hdf5 files and read density, temperature, h1 mass fraction and inner and outer block coordinates
#file    = h5py.File('supernova_new_hdf5_chk_0000','r')   # 'r' means that hdf5 file is open in read-only mode
    dataset = file['dens']
    dataset2 = file['tele']
    dataset3 = file['h1  ']
    dataset4 = file['he4 ']
    dataset5 = file['bounding box']
    dataset6 = file['real scalars']
    dataset7 = file['node type']
    dataset8 = file['trad']
    if flash_opac:
   	 dataset9 = file['opac']
	 
    if flash_heat:
    	dataset10 = file['depo']

    rho = dataset
    t = dataset2
    h = dataset3
    he = dataset4
    coord = dataset5
    time = dataset6[0][1]
    node = dataset7
    temp2 = dataset8
    if flash_opac:
  	  op = dataset9
    if flash_heat:
    	  dep = dataset10

    # Get number of blocks and zones/blocks from hdf5 data
    nblocks = len(coord)
    nzones = rho.shape[3]

    l = -1
    dx = []
    rr = []
    vol = []
    Sdep = []
    # First determine zone center coordinates using block boundary coordinates
    for i in range(0,nblocks):
        if node[i] == 1:
            for j in range(0,nzones):
                l = l + 1
                dx.append(l)
                rr.append(l)
                dx[l] = (coord[i][0][1]-coord[i][0][0])/16.
                if j == 0:
                    rr[l] = coord[i][0][0] + dx[l]/2.
                else:
                    rr[l] = rr[l-1] + dx[l]/2.
		    
		    # CAREFUL, CALCULATING Ni-56 DEPOSITION BASED ON FLASH DATA
		    
		if flash_heat:   
			vol.append(l)
			Sdep.append(l) 
	    		vol[l] = (4./3.)*math.pi*((rr[l]+dx[l]/2.)**3 - (rr[l]-dx[l]/2.)**3)
			Sdep[l] = dep.value[i][0][0][j] * vol[l] * rho.value[i][0][0][j]

    k = -1
    rho2 = []
    temp3 = []
    t2 = []
    h1_2 = []
    he4_2 = []
    z = []
    opac = []
    opac_f = []

    #print dataset.value
    for i in range(0,nblocks):
        if node[i]==1:
            for j in range(0,nzones):
                k = k + 1
                rho2.append(k)
                t2.append(k)
		temp3.append(k)

                h1_2.append(k)
                he4_2.append(k)
                z.append(k)
		
		opac_f.append(k)

                opac.append(k)

                rho2[k] = rho.value[i][0][0][j]
		temp3[k] = temp2.value[i][0][0][j]
                t2[k] = t.value[i][0][0][j]
                h1_2[k] = h.value[i][0][0][j]
                he4_2[k] = he.value[i][0][0][j]
                z[k] = 1.0 - h1_2[k] - he4_2[k]
		opac_f[k] = op.value[i][0][0][j]

    # Calculation of zone opacity using:
    # Negative H- opacity for 0 < T < 8000 K
    # Thompson opacity for 8000 < T < 20000 K
    # Kramer's opacity for T >= 20000 K if simple_opac is set to 1
    
    		if opac_source == flash_opac:
			opac[k] = opac_f[k]

                elif opac_source == simple_opac:

                    if t2[k] < 8000.:
                        opac[k] = 2.5e-31 * (z[k]/0.02) * (rho2[k]**0.5) * t2[k]**9
                    elif t2[k] >= 8000. and t2[k] < 20000.:
                        opac[k] = 0.2*(1.+ h1_2[k])
                    elif t2[k] >= 20000.:
                        opac[k] = 4.e+25 * (1. + h1_2[k]) * (z[k]+0.001) * rho2[k] / (t2[k]**3.5)    

    #If use tabular opacities call external read_opac.py routine

                else:    #opac_source = tabular

                    opac[k] = read_opac.opacity(t2[k],rho2[k],h1_2[k],opac_data_path)
                    opac[k] = 10.**opac[k]


    #Reverse order of array to start from outer zone of the simulation box
    rho2[:] = rho2[::-1]
    temp3[:] = temp3[::-1]
    t2[:] = t2[::-1]
    h1_2[:] = h1_2[::-1]
    he4_2[:] = he4_2[::-1]
    opac[:] = opac[::-1]
    dx[:] = dx[::-1]
    rr[:] = rr[::-1]
    if flash_heat:
    	Sdep[:] = Sdep[::-1]

    sum_tau = [0.,]
    tau = [0.,]

    #Calculate optical depth as a function of radius by adding optical depths of individual zones
    for i in range(0,len(rho2)):
            tau.append(i)
            sum_tau.append(i)
            tau[i] = opac[i]*rho2[i]*dx[i]
            sum_tau[i] = sum_tau[i-1]+tau[i]

    #Locate radius and temperature nearest to photosphere at tau = 2/3
    diff = [(abs(tau_phot - x),idx) for (idx,x) in enumerate(sum_tau)]
    diff.sort()
    
    #print 'DEBUGGING',diff

    R_ph = rr[diff[0][1]]
    
    if flash_heat:
    	L_heat = sum(Sdep[0:diff[0][1]-1])
    else:
    	L_heat = 0.0
    
    L_bol = 4.*math.pi*(rr[diff[0][1]]**2)*stefan*(temp3[diff[0][1]])**4 + L_heat
    delay = (Rbox - R_ph)/c

    if single == 0:
        print 'For optical depth ',tau_phot,' the radius is ',R_ph,'cm',' at time ',time,'sec'
        print 'The luminosity is ',L_bol,' erg/s'
	print 'The deposition luminosity by radioactive decay is ',L_heat

    else:
        print (time+delay)/86400.,'     ',L_bol,'     ',L_heat,'     ',R_ph, '     ',delay/86400.,'     ',time/86400.


