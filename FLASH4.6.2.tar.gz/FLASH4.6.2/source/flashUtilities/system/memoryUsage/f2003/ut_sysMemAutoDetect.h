#ifndef UT_SYSMEMAUTODETECT_H
#define UT_SYSMEMAUTODETECT_H

#include "ut_sysMem.h"

int ut_sysMemAutoDetect(void);

#endif
