#ifndef UT_SYSMEMCTYPES_H
#define UT_SYSMEMCTYPES_H

typedef struct meminfo_t
{
  double measurement;
  const char *description;
} meminfo_t;

#endif
