#define ABSORPTION 1
#define EMISSION   2
#define TRANSPORT  3

#define LOW  1
#define HIGH 2

#define OLD 1
#define NEW 2

#define OP_OPAL_NUM_H_ABUNDANCES 10
