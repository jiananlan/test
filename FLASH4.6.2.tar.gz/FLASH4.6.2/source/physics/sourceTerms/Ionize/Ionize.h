#if 0
Maximum number of elements
#endif
#define ION_NELEM 12

#if 0
Maximum number of ionization states
#endif
#define ION_NIMAX 30

#if 0
Number of temperatures in the Summers table
#endif
#define ION_NTEMP 134
