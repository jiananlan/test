#if 0
The header file Hydro_components/h contains definitions for using Hydro with multiple fluid components.
This instance is a dummy version to be used when FLASH is not configured for multiTemp Hydro,
thus there is only one fluid component.
#endif


#define HYDRO_NUM_COMPONENTS 1
