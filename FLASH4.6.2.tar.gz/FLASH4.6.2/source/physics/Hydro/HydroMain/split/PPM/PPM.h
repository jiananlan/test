!!***h* source/physics/Hydro/explicit/split/PPM/PPM.h
!!
!! This is the internal header file for the Hydro unit in 
!! its PPM incarnation.
!!***


#define UPDATE_INTERIOR 0
#define UPDATE_BOUND 1
#define UPDATE_ALL 2


