#define NUNK_VARS 2
#define NXB 2
#define NYB 3
#define NZB 2
#define NGUARD 2
#define K1D 1
#define K2D 1
#define K3D 1
