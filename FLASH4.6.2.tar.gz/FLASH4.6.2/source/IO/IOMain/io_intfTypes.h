/*
!!****ih* source/IO/IOMain/io_intfTypes.h
!!
!! NAME
!!  io_intfTypes
!!
!! SYNOPSIS
!!
!!  #include "io_intfTypes.h"
!!
!! DESCRIPTION
!!
!!  This is an auxiliary header file for declarations
!!  of types that can be used if a specific implementation
!!  does not provide something else.
!!
!!***
*/

#include "Flash.h"

#if ! defined(FLASH_IO_PNETCDF) && ! defined(FLASH_IO_HDF5)

typedef int io_fileID_t;

/* Some IO subdirectories will override the contents of this module
  with something more interesting.
*/

#endif
